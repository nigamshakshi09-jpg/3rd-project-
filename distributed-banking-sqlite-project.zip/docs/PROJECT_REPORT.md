# PROJECT REPORT
## Distributed Banking and Financial Transaction Management System

**Team Member:** Shakshi Nigam  
**Team ID:** TCA2573040  
**Platform:** DB Browser for SQLite  
**Database Engine:** SQLite

## 1. Abstract
The Distributed Banking and Financial Transaction Management System is an academic database project that organizes customer, branch, account, transaction, transfer and loan information. It demonstrates how a banking database can maintain accurate account balances, validate transactions, record audit information and produce financial summaries. SQLite triggers update balances automatically when ledger entries are inserted. Atomic SQL transactions ensure that a fund transfer is completed as a unit or rolled back if a step fails.

## 2. Problem statement
A bank must manage many customers and accounts across branches while ensuring that deposits, withdrawals and transfers are recorded correctly. Incorrect or partially completed transfers can create inconsistent balances. The system therefore needs data integrity rules, transaction recovery, concurrency handling, indexing and reporting.

## 3. Objectives
- Store customer, branch, employee, account, beneficiary and loan information.
- Record deposits, withdrawals, transfers and loan-related movements.
- Update balances automatically using database triggers.
- Prevent negative balances and reject transactions on inactive accounts.
- Use atomic transactions and rollback to protect transfers.
- Maintain an audit trail for transaction and transfer inserts.
- Improve searches with indexes and generate branch/account reports.

## 4. Software requirements
- Windows, Linux or macOS
- DB Browser for SQLite
- SQLite 3
- Optional: Python 3 for the command-line demonstration

## 5. Database design
The database contains ten main tables:
1. `CUSTOMER` — customer identity and contact information.
2. `ACCOUNT` — account owner, branch, type, balance and status.
3. `BRANCH` — branch name, city and unique IFSC-like code.
4. `BANK_TRANSACTION` — immutable-style transaction ledger entries.
5. `TRANSFER` — transfer summary with source, destination, amount and reference.
6. `LOAN` — principal, interest rate and outstanding amount.
7. `LOAN_PAYMENT` — loan payment records.
8. `EMPLOYEE` — employees assigned to branches.
9. `BENEFICIARY` — saved beneficiary accounts.
10. `AUDIT_LOG` — audit records created by triggers.

Relationships: one customer may own multiple accounts and loans; one branch may manage many accounts, employees and loans; one account may have many transaction entries; transfers connect a source and destination account.

## 6. Transaction processing
A deposit is recorded as a `DEPOSIT` ledger entry. A withdrawal is recorded as `WITHDRAWAL`. A transfer creates a debit entry for the sender, a credit entry for the receiver and one transfer summary row. These statements are enclosed in `BEGIN IMMEDIATE` and `COMMIT`. If a debit fails because of insufficient funds, the transaction must be rolled back, leaving both account balances unchanged.

## 7. Integrity and automation
Primary keys uniquely identify records. Foreign keys connect related records. CHECK constraints validate account types, statuses, positive amounts and non-negative balances. Triggers reject invalid debits, update balances and create audit records. Unique constraints protect email, phone, branch code and transfer reference values.

## 8. Concurrency and distributed concepts
SQLite allows multiple readers but serializes writers. `BEGIN IMMEDIATE` obtains a write reservation early and helps avoid competing writers changing balances at the same time. This demonstrates transaction serialization, but it is not row-level Two-Phase Locking (2PL). Branch records model cross-branch activity inside one database; separate branch databases and a distributed commit protocol would be needed for a true distributed database.

## 9. Indexing and reports
Indexes support customer-to-account lookup, branch account lookup, transaction history by account/date, transaction-type filtering and loan lookup by customer. Views provide account summaries, branch-wise deposits and customer loan summaries. `EXPLAIN QUERY PLAN` can be used to inspect index usage.

## 10. Testing
- Verify that opening balances appear in `ACCOUNT`.
- Deposit funds and confirm the balance increases.
- Withdraw within available balance and confirm the balance decreases.
- Attempt a withdrawal greater than the balance and confirm it is rejected.
- Transfer funds and verify both account balances change by equal and opposite amounts.
- Force a transfer failure and roll back; verify neither account changed.
- Inspect `AUDIT_LOG` and report views.

## 11. Limitations
This is a learning prototype, not a production banking application. SQLite does not provide PL/SQL, stored packages, database links, row-level locking or native distributed transactions. Authentication, encryption, regulatory controls, fraud detection, production-grade audit protection and real multi-server replication are outside the scope.

## 12. Future enhancements
A web/mobile interface, role-based access, stronger authentication, encrypted sensitive data, scheduled loan payments, interest calculation, notifications, and a server database with true distributed transaction support can be added.

## 13. Conclusion
The project demonstrates core DBMS concepts through a practical banking scenario. It uses relational design, constraints, triggers, atomic transactions, rollback, indexes, audit logging and reporting to maintain consistent financial records in an SQLite learning environment.
