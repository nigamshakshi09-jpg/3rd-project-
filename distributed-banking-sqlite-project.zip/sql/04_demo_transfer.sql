-- Run the statements below as one transaction in DB Browser's Execute SQL tab.
-- If any statement fails, execute ROLLBACK; neither balance will be changed.
BEGIN IMMEDIATE;
INSERT INTO BANK_TRANSACTION(account_id,transaction_type,amount,description,related_account_id)
VALUES(1001,'TRANSFER_OUT',5000,'Demo transfer to account 2001',2001);
INSERT INTO BANK_TRANSACTION(account_id,transaction_type,amount,description,related_account_id)
VALUES(2001,'TRANSFER_IN',5000,'Demo transfer from account 1001',1001);
INSERT INTO TRANSFER(from_account_id,to_account_id,amount,status,reference)
VALUES(1001,2001,5000,'COMPLETED','DEMO-TRF-001');
COMMIT;

-- Verify balances and transfer:
-- SELECT account_id,balance FROM ACCOUNT WHERE account_id IN (1001,2001);
-- SELECT * FROM TRANSFER WHERE reference='DEMO-TRF-001';
