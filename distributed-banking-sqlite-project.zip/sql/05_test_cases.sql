-- Run each test separately and inspect the result.
-- 1. Current balances
SELECT account_id,balance,status FROM ACCOUNT ORDER BY account_id;
-- 2. Customer account summary
SELECT * FROM VW_ACCOUNT_SUMMARY ORDER BY account_id;
-- 3. Branch-wise deposits
SELECT * FROM VW_BRANCH_SUMMARY ORDER BY branch_id;
-- 4. Recent transaction history
SELECT transaction_id,account_id,transaction_type,amount,description,created_at
FROM BANK_TRANSACTION ORDER BY transaction_id DESC LIMIT 20;
-- 5. Audit trail
SELECT * FROM AUDIT_LOG ORDER BY audit_id DESC LIMIT 20;
-- 6. Loan details
SELECT * FROM VW_CUSTOMER_LOANS;
-- 7. Index plan for account transaction history
EXPLAIN QUERY PLAN SELECT * FROM BANK_TRANSACTION
WHERE account_id=1001 ORDER BY created_at;
