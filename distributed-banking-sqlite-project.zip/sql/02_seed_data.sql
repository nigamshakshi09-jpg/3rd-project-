PRAGMA foreign_keys = ON;
INSERT OR IGNORE INTO BRANCH(branch_id,branch_name,city,ifsc_code) VALUES
 (1,'Moradabad Main Branch','Moradabad','DBNK0001001'),
 (2,'Prayagraj Branch','Prayagraj','DBNK0001002'),
 (3,'Lucknow Branch','Lucknow','DBNK0001003');
INSERT OR IGNORE INTO CUSTOMER(customer_id,full_name,email,phone,address) VALUES
 (1,'Rahul Sharma','rahul@example.com','9000000001','Moradabad'),
 (2,'Priya Verma','priya@example.com','9000000002','Prayagraj'),
 (3,'Amit Singh','amit@example.com','9000000003','Lucknow');
INSERT OR IGNORE INTO EMPLOYEE(employee_id,branch_id,full_name,role) VALUES
 (1,1,'Neha Gupta','Branch Manager'),(2,2,'Ravi Kumar','Account Officer'),(3,3,'Pooja Singh','Cashier');
INSERT OR IGNORE INTO ACCOUNT(account_id,customer_id,branch_id,account_type,balance,status) VALUES
 (1001,1,1,'SAVINGS',0,'ACTIVE'),
 (2001,2,2,'SAVINGS',0,'ACTIVE'),
 (3001,3,3,'CURRENT',0,'ACTIVE');
-- Opening balances are entered through the transaction ledger.
INSERT INTO BANK_TRANSACTION(account_id,transaction_type,amount,description)
SELECT 1001,'DEPOSIT',50000,'Opening balance' WHERE NOT EXISTS
 (SELECT 1 FROM BANK_TRANSACTION WHERE account_id=1001 AND description='Opening balance');
INSERT INTO BANK_TRANSACTION(account_id,transaction_type,amount,description)
SELECT 2001,'DEPOSIT',30000,'Opening balance' WHERE NOT EXISTS
 (SELECT 1 FROM BANK_TRANSACTION WHERE account_id=2001 AND description='Opening balance');
INSERT INTO BANK_TRANSACTION(account_id,transaction_type,amount,description)
SELECT 3001,'DEPOSIT',75000,'Opening balance' WHERE NOT EXISTS
 (SELECT 1 FROM BANK_TRANSACTION WHERE account_id=3001 AND description='Opening balance');
INSERT OR IGNORE INTO BENEFICIARY(beneficiary_id,customer_id,beneficiary_name,beneficiary_account_id,nickname)
VALUES(1,1,'Priya Verma',2001,'College Friend');
INSERT OR IGNORE INTO LOAN(loan_id,customer_id,branch_id,principal,interest_rate,outstanding_amount,status)
VALUES(1,1,1,100000,8.5,100000,'ACTIVE');
