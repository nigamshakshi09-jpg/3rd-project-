PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS BRANCH (
  branch_id INTEGER PRIMARY KEY,
  branch_name TEXT NOT NULL,
  city TEXT NOT NULL,
  ifsc_code TEXT NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS CUSTOMER (
  customer_id INTEGER PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE,
  phone TEXT UNIQUE,
  address TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS EMPLOYEE (
  employee_id INTEGER PRIMARY KEY,
  branch_id INTEGER NOT NULL REFERENCES BRANCH(branch_id),
  full_name TEXT NOT NULL,
  role TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS ACCOUNT (
  account_id INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES CUSTOMER(customer_id),
  branch_id INTEGER NOT NULL REFERENCES BRANCH(branch_id),
  account_type TEXT NOT NULL CHECK(account_type IN ('SAVINGS','CURRENT')),
  balance NUMERIC NOT NULL DEFAULT 0 CHECK(balance >= 0),
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','FROZEN','CLOSED')),
  opened_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS BENEFICIARY (
  beneficiary_id INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES CUSTOMER(customer_id),
  beneficiary_name TEXT NOT NULL,
  beneficiary_account_id INTEGER NOT NULL REFERENCES ACCOUNT(account_id),
  nickname TEXT
);
CREATE TABLE IF NOT EXISTS LOAN (
  loan_id INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES CUSTOMER(customer_id),
  branch_id INTEGER NOT NULL REFERENCES BRANCH(branch_id),
  principal NUMERIC NOT NULL CHECK(principal > 0),
  interest_rate NUMERIC NOT NULL CHECK(interest_rate >= 0),
  outstanding_amount NUMERIC NOT NULL CHECK(outstanding_amount >= 0),
  status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','CLOSED','DEFAULTED')),
  issued_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS LOAN_PAYMENT (
  payment_id INTEGER PRIMARY KEY,
  loan_id INTEGER NOT NULL REFERENCES LOAN(loan_id),
  account_id INTEGER NOT NULL REFERENCES ACCOUNT(account_id),
  amount NUMERIC NOT NULL CHECK(amount > 0),
  paid_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS BANK_TRANSACTION (
  transaction_id INTEGER PRIMARY KEY,
  account_id INTEGER NOT NULL REFERENCES ACCOUNT(account_id),
  transaction_type TEXT NOT NULL CHECK(transaction_type IN
    ('DEPOSIT','WITHDRAWAL','TRANSFER_IN','TRANSFER_OUT','LOAN_DISBURSEMENT','LOAN_REPAYMENT')),
  amount NUMERIC NOT NULL CHECK(amount > 0),
  description TEXT,
  related_account_id INTEGER REFERENCES ACCOUNT(account_id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS TRANSFER (
  transfer_id INTEGER PRIMARY KEY,
  from_account_id INTEGER NOT NULL REFERENCES ACCOUNT(account_id),
  to_account_id INTEGER NOT NULL REFERENCES ACCOUNT(account_id),
  amount NUMERIC NOT NULL CHECK(amount > 0),
  status TEXT NOT NULL CHECK(status IN ('COMPLETED','FAILED')),
  reference TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK(from_account_id <> to_account_id)
);
CREATE TABLE IF NOT EXISTS AUDIT_LOG (
  audit_id INTEGER PRIMARY KEY,
  table_name TEXT NOT NULL,
  record_id INTEGER NOT NULL,
  action TEXT NOT NULL,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_account_customer ON ACCOUNT(customer_id);
CREATE INDEX IF NOT EXISTS idx_account_branch ON ACCOUNT(branch_id);
CREATE INDEX IF NOT EXISTS idx_transaction_account_date ON BANK_TRANSACTION(account_id, created_at);
CREATE INDEX IF NOT EXISTS idx_transaction_type ON BANK_TRANSACTION(transaction_type);
CREATE INDEX IF NOT EXISTS idx_loan_customer ON LOAN(customer_id);

-- Reject a debit before inserting its ledger entry if funds are insufficient.
CREATE TRIGGER IF NOT EXISTS trg_transaction_validate_debit
BEFORE INSERT ON BANK_TRANSACTION
WHEN NEW.transaction_type IN ('WITHDRAWAL','TRANSFER_OUT','LOAN_REPAYMENT')
BEGIN
  SELECT CASE WHEN (SELECT status FROM ACCOUNT WHERE account_id=NEW.account_id) <> 'ACTIVE'
    THEN RAISE(ABORT, 'Account is not active') END;
  SELECT CASE WHEN (SELECT balance FROM ACCOUNT WHERE account_id=NEW.account_id) < NEW.amount
    THEN RAISE(ABORT, 'Insufficient funds') END;
END;

-- Ledger entries are the source of truth for balance movements.
CREATE TRIGGER IF NOT EXISTS trg_transaction_update_balance
AFTER INSERT ON BANK_TRANSACTION
BEGIN
  UPDATE ACCOUNT
  SET balance = balance + CASE
    WHEN NEW.transaction_type IN ('DEPOSIT','TRANSFER_IN','LOAN_DISBURSEMENT') THEN NEW.amount
    ELSE -NEW.amount END
  WHERE account_id=NEW.account_id;
END;
CREATE TRIGGER IF NOT EXISTS trg_transaction_audit
AFTER INSERT ON BANK_TRANSACTION
BEGIN
  INSERT INTO AUDIT_LOG(table_name,record_id,action,details)
  VALUES('BANK_TRANSACTION',NEW.transaction_id,'INSERT',
         NEW.transaction_type || ' amount=' || NEW.amount || ' account=' || NEW.account_id);
END;
CREATE TRIGGER IF NOT EXISTS trg_transfer_audit
AFTER INSERT ON TRANSFER
BEGIN
  INSERT INTO AUDIT_LOG(table_name,record_id,action,details)
  VALUES('TRANSFER',NEW.transfer_id,'INSERT',
         'Transfer ' || NEW.reference || ' ' || NEW.amount || ' from ' || NEW.from_account_id || ' to ' || NEW.to_account_id);
END;
