CREATE VIEW IF NOT EXISTS VW_ACCOUNT_SUMMARY AS
SELECT a.account_id,c.full_name,b.branch_name,b.city,a.account_type,a.balance,a.status
FROM ACCOUNT a JOIN CUSTOMER c ON c.customer_id=a.customer_id
JOIN BRANCH b ON b.branch_id=a.branch_id;

CREATE VIEW IF NOT EXISTS VW_BRANCH_SUMMARY AS
SELECT b.branch_id,b.branch_name,b.city,COUNT(a.account_id) AS total_accounts,
       COALESCE(SUM(a.balance),0) AS total_deposits
FROM BRANCH b LEFT JOIN ACCOUNT a ON a.branch_id=b.branch_id
GROUP BY b.branch_id,b.branch_name,b.city;

CREATE VIEW IF NOT EXISTS VW_CUSTOMER_LOANS AS
SELECT l.loan_id,c.full_name,b.branch_name,l.principal,l.interest_rate,
       l.outstanding_amount,l.status
FROM LOAN l JOIN CUSTOMER c ON c.customer_id=l.customer_id
JOIN BRANCH b ON b.branch_id=l.branch_id;
