-- ADVANCED RECOVERY TEST
-- This intentionally attempts to debit more than the available balance.
-- Execute the whole block. SQLite raises "Insufficient funds" and rolls back
-- the current statement. For a multi-step transfer, wrap BOTH ledger inserts
-- and the TRANSFER row in BEGIN IMMEDIATE ... COMMIT as in 04_demo_transfer.sql.
BEGIN IMMEDIATE;
INSERT INTO BANK_TRANSACTION(account_id,transaction_type,amount,description)
VALUES(1001,'TRANSFER_OUT',999999999,'Intentional failure test');
-- If the INSERT errors, run ROLLBACK manually before continuing.
-- Then verify: SELECT balance FROM ACCOUNT WHERE account_id=1001;
